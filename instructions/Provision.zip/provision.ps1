# Use the new Azure Resource Manager mode
Switch-AzureMode AzureResourceManager

###########################################
# Create required items, if none exist
###########################################

# Sign in
Add-AzureAccount

# Select the subscription to use
$subscriptionName = "Azure Pass"        # Provide your Subscription Name
Select-AzureSubscription -SubscriptionName $subscriptionName

# Register your subscription to use HDInsight
Register-AzureProvider -ProviderNamespace "Microsoft.HDInsight" -Force

# Create an Azure Resource Group
$resourceGroupName = "MyGroup"      # Provide a Resource Group name
$location = "East Asia"                        # For example, "West US"
New-AzureResourceGroup -Name $resourceGroupName -Location $location

# Create an Azure Storage account
$storageAccountName = "gerasimov"   # Provide a Storage account name
New-AzureStorageAccount -ResourceGroupName $resourceGroupName -StorageAccountName $storageAccountName -Location $location -Type Standard_LRS

Start-Sleep -s 30


# Create an Azure Blob Storage container
$containerName = "gerasimov"              # Provide a container name
$storageAccountKey = Get-AzureStorageAccountKey -Name $storageAccountName -ResourceGroupName $resourceGroupName | %{ $_.Key1 }
Start-Sleep -s 10
$destContext = New-AzureStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $storageAccountKey
Start-Sleep -s 30
New-AzureStorageContainer -Name $containerName -Context $destContext
Start-Sleep -s 10

###########################################
# Create an HDInsight Cluster
###########################################

# Skip these variables if you just created them
#$resourceGroupName = "<ResourceGroupName>"      # Provide the Resource Group name
#$storageAccountName = "<StorageAcccountName>"   # Provide the Storage account name
#$containerName = "<ContainerName>"              # Provide the container name
#$storageAccountKey = Get-AzureStorageAccountKey -Name $storageAccountName -ResourceGroupName $resourceGroupName | %{ $_.Key1 }

# Set these variables
$clusterName = $containerName                   # As a best practice, have the same name for the cluster and container
$clusterNodes = 2            # The number of nodes in the HDInsight cluster

$headNodeVmSize="large"
$vmSize="large" 

#New-AzureHDInsightClusterConfig [-ClusterSizeInNodes] <Int32> [[-HeadNodeVMSize] <NodeVMSize> ] [ <CommonParameters>]



#hdiconfig = New-AzureHDInsightClusterConfig -HeadNodeSize $headNodeVmSize `
#                                           -WorkerNodeSize $vmSize `
#                                           -ClusterType "Hadoop" `

$credentials = Get-Credential
$sshCredentials = Get-Credential

# The location of the HDInsight cluster. It must be in the same data center as the Storage account.
$location = Get-AzureStorageAccount -ResourceGroupName $resourceGroupName -StorageAccountName $storageAccountName | %{$_.Location}

#New-AzureHDInsightCluster -Name $clusterName -Config $hdiconfig 
#-Location $location -Credential $credentials
#-Version "3.2"

# Create a new HDInsight cluster
New-AzureHDInsightCluster -ClusterName $clusterName -ResourceGroupName $resourceGroupName -HttpCredential $credentials -Location $location `
-DefaultStorageAccountName "$storageAccountName.blob.core.windows.net" -DefaultStorageAccountKey $storageAccountKey -DefaultStorageContainer $containerName `
-OSType Linux -Version "3.2" -SshCredential $sshCredentials  -ClusterSizeInNodes $clusterNodes -HeadNodeSize $headNodeVmSize `
                                            -WorkerNodeSize $vmSize `
                                            -ClusterType "Hadoop"




